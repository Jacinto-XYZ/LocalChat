#include "socketthread.h"
#include "usermanager.h"
//因为usermanager里面有Socketthread，必须放cpp中
//避免头文件互相指向导致编译器无法找到对应的声明，常见报错为XXX undeclared

SocketThread::SocketThread(QTcpSocket* socket)
    :socket(socket),isrun(true)
{
    connect(this->socket,SIGNAL(readyRead()),this,SLOT(slot_read()));
    udao= UserDao::getins();
    connect(this->socket,SIGNAL(disconnected()),this,SLOT(slot_isDisconnected()));
}

SocketThread::~SocketThread()
{

}
void SocketThread::run()
{
//    qDebug()<<"客户端连接";
    while(isrun)//当客户端下线的时候结束处理
    {
        //延时操作
        QThread::msleep(1000);
    }
    socket->close();

}
void SocketThread::slot_read()
{
    QByteArray arr=socket->readAll();
    //获取消息类型
    int type = MsgBuilder::msgType(arr);
//    qDebug()<<"type:"<<type;
    switch (type)
    {
    case MsgBuilder::registerUser:  //注册消息
        dealUserRegister(arr);
        break;
    case MsgBuilder::login:  //登录消息
        dealUserLogin(arr);
        break;
    case MsgBuilder::sendMsg:  //收取消息
        dealUserSendMsg(arr);
        break;
    case MsgBuilder::receiveMsg: //发送消息
       dealUserRecieveMsg(user,arr);
    case MsgBuilder::sendFace:
        dealUserSendFace(arr);
        break;
    case MsgBuilder::receiveFace:
        dealUserRecieveFace(user,arr);
    default:
        break;
    }
}

void SocketThread::slot_isDisconnected()
{
    isrun=false;
    //用户下线，通知所有人
    vector<SocketThread*> sts= UserManager::getOne()->getonlineThread();
    //遍历容器
    for(auto it=sts.begin();it!=sts.end();it++)
    {
        (*it)->dealUserOffline(user);
    }
    //广播完毕，删除容器内对应成员
    UserManager::getOne()->eraseMap(user);
}
void SocketThread::dealUserRegister(QByteArray msg)
{
    UserData data;
    data=MsgBuilder::parseRegisterUserMsg(msg);
//    QString msg="nickname:"+data.nickName+"\n"+"password:"+data.passWord
//            +"\n"+"headid:"+QString().setNum(data.headId);
//    ui->textBrowser->append(msg);
    udao->insertvalues(data);
    int id=udao->getUserId();
//    ui->textBrowser->append(QString().setNum(id));
    QString jsonstr = MsgBuilder::buildRegisterUserReturnMsg(id);
    socket->write(jsonstr.toLocal8Bit());
}

void SocketThread::dealUserLogin(QByteArray msg)
{
    UserData data;
    data=MsgBuilder::parseLoginMsg(msg);
    bool ok=udao->usercheck(data);
    if(ok)//用户信息存在
    {
        UserManager* p= UserManager::getOne();
        vector<UserData> friends=p->getOnlineFriends();//好友容器
        //判断
        if(p->isExists(data))//已存在
        {
            return;
        }
        this->user=data;//保存当前登录用户
        /*广播所有人，该用户上线*/
        //获取其他好友子线程
        vector<SocketThread*> sts= UserManager::getOne()->getonlineThread();
        //遍历容器
        for(auto it=sts.begin();it!=sts.end();it++)
        {
            (*it)->dealUserOnline(data);
        }
        p->insertMap(data,this);
        QString jsonstr = MsgBuilder::buildLoginReturnMsg(ok,data,friends);
//        qDebug()<<jsonstr;
        socket->write(jsonstr.toLocal8Bit());
    }
    else
    {
        QString jsonstr = MsgBuilder::buildLoginReturnMsg(ok);
        socket->write(jsonstr.toLocal8Bit());
    }

}

void SocketThread::dealUserOnline(UserData user)
{
    //构建json串
    QString msg = MsgBuilder::buildUserOnline(user);
    socket->write(msg.toLocal8Bit());
}

void SocketThread::dealUserOffline(UserData user)
{
    QString msg = MsgBuilder::buildUserOffline(user);
    socket->write(msg.toLocal8Bit());
}

void SocketThread::dealUserSendMsg(QByteArray msg)
{
    UserData user,fri;
    QString data=MsgBuilder::parseSendMsg(msg,user,fri);
    //获取聊天对象的子线程
    SocketThread* st = UserManager::getOne()->getRecvThread(fri);
    if(st!=nullptr)
    {
        st->dealUserRecieveMsg(user,data);
    }
}

void SocketThread::dealUserRecieveMsg(UserData user, QString msg)
{
    QString json = MsgBuilder::buildReceiveMsg(user,msg);
//    qDebug()<<"send:";
    socket->write(json.toLocal8Bit());
}

void SocketThread::dealUserSendFace(QByteArray msg)
{
    UserData user,fri;
    QString data=MsgBuilder::parseSendFace(msg,user,fri);
    //获取聊天对象的子线程
    SocketThread* st = UserManager::getOne()->getRecvThread(fri);
    if(st!=nullptr)
    {
        st->dealUserRecieveFace(user,data);
    }
}

void SocketThread::dealUserRecieveFace(UserData user, QString msg)
{
    QString json = MsgBuilder::buildReceiveFace(user,msg);
    socket->write(json.toLocal8Bit());
}
