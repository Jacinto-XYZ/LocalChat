#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    initIp();

    server=new MyServer(this);
    //监听，QHostAddress::Any任何IP地址
    server->listen(QHostAddress::Any,12345);
    //当有客户端连接时，服务器会发送newconnection信号
//    connect(server,SIGNAL(newConnection()),this,SLOT(slot_newconnect()));
    ui->textBrowser->append("server ready");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::initIp()
{
    //获取主机名称
    QString hostname = QHostInfo::localHostName();
    //获取主机信息
    QHostInfo info = QHostInfo::fromName(hostname);
    //获取ip地址,qlist容器装
    QList<QHostAddress> addlist = info.addresses();
    //定义保存ipv4的地址
    QString ip;
    //遍历
    for(int i=0;i<addlist.size();i++)
    {
        if(addlist[i].protocol()==QAbstractSocket::IPv4Protocol)
        {
            //拼接
            ip+='*';
            ip+=addlist[i].toString();//qhostinfo转string
        }
    }
    ui->label_ip->setText(ip);
}



//void MainWindow::slot_newconnect()
//{
//    qDebug()<<"有用户连接";
//    //获取与之通信的套接字
//    socket=server->nextPendingConnection();
//}


