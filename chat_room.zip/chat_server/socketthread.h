#ifndef SOCKETTHREAD_H
#define SOCKETTHREAD_H
#include <QThread>
#include<QTcpSocket>
#include <QTcpServer>
#include "userdao.h"


//子线程类
class SocketThread:public QThread
{
    Q_OBJECT

public:
    SocketThread(QTcpSocket* socket);
    void run();
    void dealUserRegister(QByteArray msg);//处理用户注册
    void dealUserLogin(QByteArray msg);//处理用户登录
    void dealUserOnline(UserData user);
    void dealUserOffline(UserData user);
    void dealUserSendMsg(QByteArray msg);//处理用户发送消息
    void dealUserRecieveMsg(UserData user, QString msg);//处理用户接受信息
    void dealUserSendFace(QByteArray msg);//处理用户发送表情
    void dealUserRecieveFace(UserData user, QString msg);//处理用户接受表情
    ~SocketThread();
//signals:
//    void signals_send(QString text);
private:
    QTcpSocket* socket;
    UserDao* udao;
    UserData user;//保存登录信息
    bool isrun;//标志连接状态
private slots:
    void slot_read();
    void slot_isDisconnected();
};

#endif // SOCKETTHREAD_H
