#include "myserver.h"

MyServer::MyServer(QObject *parent)
    :QTcpServer(parent)
{

}

void MyServer::incomingConnection(qintptr socketDescriptor)
{
    //创建套接字指针
    QTcpSocket* socket=new QTcpSocket;
    //设置套接字描述
    socket->setSocketDescriptor(socketDescriptor);
    //创建子线程
    SocketThread *st=new SocketThread(socket);
    //开启线程
    st->start();
    //连接,当线程完毕时会发送finished信号，调用自带槽函数析构
    connect(st,SIGNAL(finished()),st,SLOT(deleteLater()));

}

MyServer::~MyServer()
{


}

