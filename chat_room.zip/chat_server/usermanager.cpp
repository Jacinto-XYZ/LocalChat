#include "usermanager.h"

UserManager* UserManager::one=new UserManager;

UserManager::UserManager()
{

}

UserManager *UserManager::getOne()
{
    return one;
}

void UserManager::insertMap(UserData user, SocketThread *st)
{
    mutex.lock();
    pair<UserData,SocketThread* > p(user,st);
    onlineUsers.insert(p);
//    onlineUsers[user] =st;
    mutex.unlock();
}

vector<UserData> UserManager::getOnlineFriends()
{
    vector<UserData> friends;
    map<UserData,SocketThread*>::iterator it;
    for(it=onlineUsers.begin();it!=onlineUsers.end();it++)
    {
        friends.push_back(it->first);
    }
    return friends;
}

bool UserManager::isExists(UserData user)
{
    if(onlineUsers.count(user)==1)//判断存在
        return true;
    else
        return false;
}

vector<SocketThread *> UserManager::getonlineThread()
{
    vector<SocketThread*> sts;
    //遍历容器
    map<UserData,SocketThread*>::iterator it;
    for(it=onlineUsers.begin();it!=onlineUsers.end();it++)
    {
       sts.push_back(it->second);
    }
    return sts;
}

void UserManager::eraseMap(UserData user)
{
    //判断存不存在
    if(!isExists(user))
    {
        return;
    }
    mutex.lock();//加锁
    onlineUsers.erase(user);//删除
    mutex.unlock();
}

SocketThread *UserManager::getRecvThread(UserData user)
{
    SocketThread* th=nullptr;
    map<UserData,SocketThread*>::iterator it=onlineUsers.find(user);
    //判断是否找到了
    if(it!=onlineUsers.end())
    {
        return it->second;
    }
    return th;
}

UserManager::~UserManager()
{

}


