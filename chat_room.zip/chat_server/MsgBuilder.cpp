#include "MsgBuilder.h"

int MsgBuilder::msgType(QByteArray& arr)
{
    //QJsonDocument用于字符串和json对象之间的转换
    QJsonDocument doc = QJsonDocument::fromJson(arr);
    //获得json对象容器的对象
    QJsonObject parse = doc.object();
    //解析获取数据
    int type = parse.value("type").toInt();
    return type;
}

QString MsgBuilder::buildRegisterUserMsg(UserData& user)
{
    QJsonObject json;//创建一个对象容器
    //插入数据
    json.insert("type", registerUser);
    json.insert("headid", user.headId);
    json.insert("nickname", user.nickName);
    json.insert("password", user.passWord);
    QJsonDocument doct;//QJsonDocument用于字符串和json对象之间的转换
    doct.setObject(json);//将构建好的json对象设置被QJsonDocument对象
    QByteArray byte = doct.toJson();//将json对象转换成json字符串，返回值是字节数组
    QString jsonStr(byte);//使用字节数组创建字符串
    return jsonStr;
}

UserData MsgBuilder::parseRegisterUserMsg(QByteArray& arr)
{
    UserData user;
    //使用json字符串创建
    QJsonDocument doc = QJsonDocument::fromJson(arr);
    QJsonObject parse = doc.object();//获得json对象容器的对象
    //解析获取数据
    user.nickName = parse.value("nickname").toString();
    user.passWord = parse.value("password").toString();
    user.headId = parse.value("headid").toInt();
    return user;
}

QString MsgBuilder::buildRegisterUserReturnMsg(int id)
{
    QJsonObject json;//创建一个对象容器
    //插入数据
    json.insert("type", registerUserReturn);
    json.insert("userId", id);
    QJsonDocument doct;//QJsonDocument用于字符串和json对象之间的转换
    doct.setObject(json);//将构建好的json对象设置被QJsonDocument对象
    QByteArray byte = doct.toJson();//将json对象转换成json字符串，返回值是字节数组
    QString jsonStr(byte);//使用字节数组创建字符串
    return jsonStr;
}

int MsgBuilder::parseRegisterUserReturnMsg(QByteArray& arr)
{
    int id;
    //使用json字符串创建
    QJsonDocument doc = QJsonDocument::fromJson(arr);
    QJsonObject parse = doc.object();//获得json对象容器的对象
    id = parse.value("userId").toInt();//解析获取数据
    return id;
}

QString MsgBuilder::buildLoginMsg(UserData &user)
{
    QJsonObject json;//创建一个对象容器
    //插入数据
    json.insert("type", login);
    json.insert("userId", user.userId);
    json.insert("password", user.passWord);
    QJsonDocument doct;//QJsonDocument用于字符串和json对象之间的转换
    doct.setObject(json);//将构建好的json对象设置被QJsonDocument对象
    QByteArray byte = doct.toJson();//将json对象转换成json字符串，返回值是字节数组
    QString jsonStr(byte);//使用字节数组创建字符串
    return jsonStr;
}

UserData MsgBuilder::parseLoginMsg(QByteArray &arr)
{
    UserData user;
    //使用json字符串创建
    QJsonDocument doc = QJsonDocument::fromJson(arr);
    QJsonObject parse = doc.object();//获得json对象容器的对象
    user.userId = parse.value("userId").toInt();
    user.passWord = parse.value("password").toString();
    return user;
}

QString MsgBuilder::buildLoginReturnMsg(bool flag, UserData user,vector<UserData> friends)
{
    QJsonObject object;//创建一个对象容器
    if(flag)//成功
    {
        //消息类型
        object.insert("type",loginSucReturn);
        //登陆者自己的信息
        object.insert("hostId",user.userId);
        object.insert("hostHeadId",user.headId);
        object.insert("hostNickName",user.nickName);

        QJsonArray Array;//[   ] 其他用户的信息
        for(int i=0;i<(int)friends.size();i++)
        {
            QJsonObject obj;//每个人是一个json对象
            obj.insert("id",friends[i].userId);
            obj.insert("headId",friends[i].headId);
            obj.insert("nickname",friends[i].nickName);
            Array.append(obj);
        }
        object.insert("friends",Array);
    }else
    {
        //消息类型
        object.insert("type",loginLoseReturn);
    }
    QJsonDocument doct;//QJsonDocument用于字符串和json对象之间的转换
    doct.setObject(object);//将构建好的json对象设置被QJsonDocument对象
    QByteArray byte = doct.toJson();//将json对象转换成json字符串，返回值是字节数组
    QString jsonStr(byte);//使用字节数组创建字符串
    return jsonStr;
}

vector<UserData> MsgBuilder::parseLoginSucReturnMsg(UserData& hostData, QByteArray& arr)
{
    vector<UserData> friends;
    //使用json字符串创建
    QJsonDocument doc = QJsonDocument::fromJson(arr);
    QJsonObject parse = doc.object();//获得json对象容器的对象
    hostData.userId = parse.value("hostId").toInt();
    hostData.nickName = parse.value("hostNickName").toString();
    hostData.headId = parse.value("hostHeadId").toInt();
    //创建数组容器
    QJsonArray userArr = parse.value("friends").toArray();
    for(QJsonArray::iterator iter = userArr.begin();iter != userArr.end();iter++)
    {
        //解析获取好友信息
        UserData ud;
        QJsonObject user = iter->toObject();//每个人是一个json对象
        ud.userId = user.value("userid").toInt();
        ud.nickName = user.value("nickname").toString();
        ud.headId = user.value("headid").toInt();
        friends.push_back(ud);
    }
    return friends;
}

QString MsgBuilder::buildSendMsg(UserData from, UserData to, QString msg)
{
    QJsonObject json;//创建一个对象容器
    json.insert("type", sendMsg);
    json.insert("fromId", from.userId);
    json.insert("toId", to.userId);
    json.insert("msg", msg);
    json.insert("fromHeadId",from.headId);
    QJsonDocument doct;//QJsonDocument用于字符串和json对象之间的转换
    doct.setObject(json);//将构建好的json对象设置被QJsonDocument对象
    QByteArray byte = doct.toJson();//将json对象转换成json字符串，返回值是字节数组
    QString jsonStr(byte);//使用字节数组创建字符串
    return jsonStr;
}

QString MsgBuilder::parseSendMsg(QByteArray &arr, UserData &from, UserData &to)
{
    //使用json字符串创建
    QJsonDocument doc = QJsonDocument::fromJson(arr);
    QJsonObject parse = doc.object();//获得json对象容器的对象
    from.userId = parse.value("fromId").toInt();
    to.userId = parse.value("toId").toInt();
    QString msg = parse.value("msg").toString();
    from.headId = parse.value("fromHeadId").toInt();
    return msg;
}

QString MsgBuilder::buildReceiveMsg(UserData from, QString msg)
{
    QJsonObject json;//创建一个对象容器
    json.insert("type", receiveMsg);
    json.insert("fromId", from.userId);
    json.insert("fromHeadId",from.headId);
    json.insert("msg", msg);
    QJsonDocument doct;//QJsonDocument用于字符串和json对象之间的转换
    doct.setObject(json);//将构建好的json对象设置被QJsonDocument对象
    QByteArray byte = doct.toJson();//将json对象转换成json字符串，返回值是字节数组
    QString jsonStr(byte);//使用字节数组创建字符串
    return jsonStr;
}

QString MsgBuilder::parseReceiveMsg(QByteArray &arr, UserData &from)
{
    //使用json字符串创建
    QJsonDocument doc = QJsonDocument::fromJson(arr);
    QJsonObject parse = doc.object();//获得json对象容器的对象
    from.userId = parse.value("fromId").toInt();
    from.headId = parse.value("fromHeadId").toInt();
    QString msg = parse.value("msg").toString();
    return msg;
}

QString MsgBuilder::buildUserOnline(UserData& user)
{
    QJsonObject json;//创建一个对象容器
    json.insert("type", userOnline);
    json.insert("userId", user.userId);
    json.insert("headId", user.headId);
    json.insert("nickname", user.nickName);
    QJsonDocument doct;//QJsonDocument用于字符串和json对象之间的转换
    doct.setObject(json);//将构建好的json对象设置被QJsonDocument对象
    QByteArray byte = doct.toJson();//将json对象转换成json字符串，返回值是字节数组
    QString jsonStr(byte);//使用字节数组创建字符串
    return jsonStr;
}

UserData MsgBuilder::parseUserOnline(QByteArray &arr)
{
    UserData user;
    //使用json字符串创建
    QJsonDocument doc = QJsonDocument::fromJson(arr);
    QJsonObject parse = doc.object();//获得json对象容器的对象
    user.userId = parse.value("userId").toInt();
    user.headId = parse.value("headId").toInt();
    user.nickName = parse.value("nickname").toString();
    return user;
}

QString MsgBuilder::buildUserOffline(UserData user)
{
    QJsonObject json;//创建一个对象容器
    json.insert("type", userOffline);
    json.insert("userId", user.userId);
    json.insert("headId", user.headId);
    json.insert("nickname", user.nickName);
    QJsonDocument doct;//QJsonDocument用于字符串和json对象之间的转换
    doct.setObject(json);//将构建好的json对象设置被QJsonDocument对象
    QByteArray byte = doct.toJson();//将json对象转换成json字符串，返回值是字节数组
    QString jsonStr(byte);//使用字节数组创建字符串
    return jsonStr;
}

UserData MsgBuilder::parseUserOffline(QByteArray &arr)
{
    UserData user;
    //使用json字符串创建
    QJsonDocument doc = QJsonDocument::fromJson(arr);
    QJsonObject parse = doc.object();//获得json对象容器的对象
    user.userId = parse.value("userId").toInt();
    user.headId = parse.value("headId").toInt();
    user.nickName = parse.value("nickname").toString();
    return user;
}
QString MsgBuilder::buildSendFace(UserData from, UserData to, QString msg)
{
    QJsonObject json;//创建一个对象容器
    json.insert("type", sendFace);
    json.insert("fromId", from.userId);
    json.insert("toId", to.userId);
    json.insert("msg", msg);
    json.insert("fromHeadId",from.headId);
    QJsonDocument doct;//QJsonDocument用于字符串和json对象之间的转换
    doct.setObject(json);//将构建好的json对象设置被QJsonDocument对象
    QByteArray byte = doct.toJson();//将json对象转换成json字符串，返回值是字节数组
    QString jsonStr(byte);//使用字节数组创建字符串
    return jsonStr;
}

QString MsgBuilder::parseSendFace(QByteArray &arr, UserData &from, UserData &to)
{
    //使用json字符串创建
    QJsonDocument doc = QJsonDocument::fromJson(arr);
    QJsonObject parse = doc.object();//获得json对象容器的对象
    from.userId = parse.value("fromId").toInt();
    to.userId = parse.value("toId").toInt();
    QString msg = parse.value("msg").toString();
    from.headId = parse.value("fromHeadId").toInt();
    return msg;
}

QString MsgBuilder::buildReceiveFace(UserData from, QString msg)
{
    QJsonObject json;//创建一个对象容器
    json.insert("type", receiveFace);
    json.insert("fromId", from.userId);
    json.insert("fromHeadId",from.headId);
    json.insert("msg", msg);
    QJsonDocument doct;//QJsonDocument用于字符串和json对象之间的转换
    doct.setObject(json);//将构建好的json对象设置被QJsonDocument对象
    QByteArray byte = doct.toJson();//将json对象转换成json字符串，返回值是字节数组
    QString jsonStr(byte);//使用字节数组创建字符串
    return jsonStr;
}

QString MsgBuilder::parseReceiveFace(QByteArray &arr, UserData &from)
{
    //使用json字符串创建
    QJsonDocument doc = QJsonDocument::fromJson(arr);
    QJsonObject parse = doc.object();//获得json对象容器的对象
    from.userId = parse.value("fromId").toInt();
    from.headId = parse.value("fromHeadId").toInt();
    QString msg = parse.value("msg").toString();
    return msg;
}

