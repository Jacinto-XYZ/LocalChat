#include "friendlist.h"
#include "ui_friendlist.h"

Friendlist::Friendlist(UserData user, vector<UserData> friends, QWidget *parent) :
    QMainWindow(parent),friends(friends),
    ui(new Ui::Friendlist)
{
    ui->setupUi(this);
    ui->label__nickname->setText(user.nickName);
    QString path=QString(":/head/head%1.jpg").arg(user.headId);
    QPixmap p(path);
    p=p.scaled(QSize(80,80),Qt::IgnoreAspectRatio);
    p=Globalobserver::PixmapToRound(p,p.width()/2);
    ui->pushButton_head->setIcon(QIcon(p));
    initList();//显示好友列表
    //获取套接字对象
    socket=MySocket::getpoint();
    socket->setSelf(user);//保存个人信息
    setWindowTitle("friendlist");
    connect(socket,SIGNAL(readyRead()),this,SLOT(slot_onReadyRead()));
    //去掉点中的蓝色条效果
    ui->listWidget->setSelectionMode(QAbstractItemView::NoSelection);
}

Friendlist::~Friendlist()
{
    delete ui;
}

void Friendlist::initList()
{
    //遍历好友容器
    for(int i=0;i<(int)friends.size();i++)
    {
        //创建自定义控件
        FriendForm* fp=new FriendForm(friends[i],ui->listWidget);
        //创建行对象
        QListWidgetItem *item=new QListWidgetItem(ui->listWidget);
        //修改尺寸
        item->setSizeHint(fp->size());
        //绑定
        ui->listWidget->setItemWidget(item,fp);
    }
}

void Friendlist::dealUserOnline(QByteArray data)
{
    //解析json
    UserData user=MsgBuilder::parseUserOnline(data);
    FriendForm* fp=new FriendForm(user);
    QListWidgetItem *item=new QListWidgetItem(ui->listWidget);
    item->setSizeHint(fp->size());
    ui->listWidget->setItemWidget(item,fp);
}

void Friendlist::dealUserOffline(QByteArray data)
{
    UserData user = MsgBuilder::parseUserOffline(data);
    for(int i=0;i<ui->listWidget->count();i++)//count记录widget内行对象数量
    {
        //获取行对象
        QListWidgetItem* item=ui->listWidget->item(i);
        //获取控件
        QWidget* w= ui->listWidget->itemWidget(item);
        //父子间类型转换
        FriendForm* f=dynamic_cast<FriendForm*> (w);
        //判断是不是下线好友
        if(f->getUser().userId==user.userId)
        {
            ui->listWidget->takeItem(i);//异常
            delete f;
            delete item;
            break;
        }
    }
//    for(int i=0;i<(int)friends.size();i++)
//    {
//        //创建自定义控件
//        FriendForm* fp=new FriendForm(friends[i],ui->listWidget);
//        //创建行对象
//        QListWidgetItem *item=new QListWidgetItem(ui->listWidget);
//        //修改尺寸
//        item->setSizeHint(fp->size());
//        //绑定
//        ui->listWidget->setItemWidget(item,fp);
    //    }
}

void Friendlist::dealUserRecvMsg(QByteArray data)
{
    UserData from;//保存好友信息
    QString msg = MsgBuilder::parseReceiveMsg(data,from);

    if(chatFriends.count(from))//聊天对象窗口已打开
    {
        //获取聊天信息
        ItemAndChat iac=chatFriends[from];
        ChatDialog *chat=iac.chat;
        //判断窗口是否隐藏
        if(!chat->isHidden())
        {
            //没隐藏
            chat->CreateWidgetL_R(1,msg);
        }
        else
        {
            //添加未读消息
            iac.f->addWaitMsg(msg);
            iac.f->msgTips(true);
        }
    }
    else//聊天窗口没打开，显示未读
    {
        for(int i=0;i<ui->listWidget->count();i++)//count记录widget内行对象数量
        {
            //获取行对象
            QListWidgetItem* item=ui->listWidget->item(i);
            //获取控件
            QWidget* w= ui->listWidget->itemWidget(item);
            //父子间类型转换
            FriendForm* f=dynamic_cast<FriendForm*> (w);
            //判断是不是下线好友
            if(f->getUser().userId==from.userId)
            {
                //添加未读信息
                f->addWaitMsg(msg);
                f->msgTips(true);
            }
        }
    }
}
void Friendlist::dealUserRecvFace(QByteArray data)
{
    UserData from;//保存好友信息
    QString msg = MsgBuilder::parseReceiveFace(data,from);

    if(chatFriends.count(from))//聊天对象窗口已打开
    {
        //获取聊天信息
        ItemAndChat iac=chatFriends[from];
        ChatDialog *chat=iac.chat;
        //判断窗口是否隐藏
        if(!chat->isHidden())
        {
            //没隐藏
            chat->CreateExpressionL_R(1,msg);
        }
        else
        {
            //添加未读消息
            msg+="/";
            iac.f->addWaitMsg(msg);
            iac.f->msgTips(true);
        }
    }
    else//聊天窗口没打开，显示未读
    {
        for(int i=0;i<ui->listWidget->count();i++)//count记录widget内行对象数量
        {
            //获取行对象
            QListWidgetItem* item=ui->listWidget->item(i);
            //获取控件
            QWidget* w= ui->listWidget->itemWidget(item);
            //父子间类型转换
            FriendForm* f=dynamic_cast<FriendForm*> (w);
            //判断是不是下线好友
            if(f->getUser().userId==from.userId)
            {
                //添加未读信息
                msg+="/";
                f->addWaitMsg(msg);
                f->msgTips(true);
            }
        }
    }
}

void Friendlist::slot_onReadyRead()
{
    //获取接受的信息
    QByteArray data = socket->readAll();
    //获取消息类型
    int type=MsgBuilder::msgType(data);
    switch (type)
    {
    case MsgBuilder::userOnline://用户上线
        dealUserOnline(data);
        break;
    case MsgBuilder::userOffline ://用户下线
        dealUserOffline(data);
        break;
    case MsgBuilder::receiveMsg ://接收信息
        dealUserRecvMsg(data);
        break;
    case MsgBuilder::receiveFace://接受表情
        dealUserRecvFace(data);
        break;
    default:
        break;
    }
}

//void Friendlist::slot_getMsg(QByteArray data)
//{
//    vector<UserData> friends;
//    UserData hostData;
//    friends=MsgBuilder::parseLoginSucReturnMsg(hostData,data);

//    ui->pushButton_head->set
//}

void Friendlist::on_listWidget_itemDoubleClicked(QListWidgetItem *item)
{
    //获取控件
    QWidget* w=ui->listWidget->itemWidget(item);
    FriendForm* f=dynamic_cast<FriendForm*>(w);
    //获取好友信息
    UserData fri = f->getUser();
    //判断窗口是否打开
    if(chatFriends.count(fri))//打开了
    {
        //获取聊天信息结构体
        ItemAndChat ian=chatFriends[fri];
        //获取单聊窗口
        ChatDialog *ch=ian.chat;
        ian.isShow=true;
        //未读信息处理
        if(ch->isHidden())
        {
            ch->show();//弹窗
            ian.f->msgTips(false);//消除提醒，
            QStringList li=f->getWaitMsg();//获取未读信息
            ch->showWaitMsg(li);//显示未读信息
        }

        return;
    }
    //没打开的未读显示
    f->msgTips(false);
    QStringList li=f->getWaitMsg();//获取未读信息
    //切换单聊窗口
    ChatDialog* chat=new ChatDialog(fri,this);
    chat->show();
    chat->showWaitMsg(li);
    //创建聊天信息的结构体
    ItemAndChat ic;
    ic.chat=chat;
    ic.f=f;
    ic.isShow=true;
    //存map
    chatFriends[fri]=ic;
}
