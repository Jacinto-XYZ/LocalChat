#include "chatdialog.h"
#include "ui_chatdialog.h"

ChatDialog::ChatDialog(UserData fri_user,QWidget *parent) :
    QDialog(parent),fri_user(fri_user),
    ui(new Ui::ChatDialog)
{
    ui->setupUi(this);
    //拼接路径
    QString path=QString(":/head/head%1.jpg").arg(fri_user.headId);
    //设置窗口图像
    setWindowIcon(QIcon(path));
    //拼接标题
    QString title= QString("聊天对象：%1").arg(fri_user.nickName);
    //屏蔽右上角 关闭窗口功能
    Qt::WindowFlags windowFlag = Qt::Dialog;
    windowFlag |= Qt::WindowMinimizeButtonHint;//最小化
    windowFlag |= Qt::WindowMaximizeButtonHint;//最大化
    windowFlag &= ~Qt::WindowCloseButtonHint;//屏蔽掉 x关闭功能
    setWindowFlags(windowFlag);
    //获取套接字对象
    socket=MySocket::getpoint();
    //获取本人信息
    self = socket->getSelf();
    //好友头像
    pixmap=QPixmap(path);
    pixmap=pixmap.scaled(QSize(60,60),Qt::IgnoreAspectRatio);
    pixmap=Globalobserver::PixmapToRound(pixmap,pixmap.width()/2);
    //自己头像
    path=QString(":/head/head%1.jpg").arg(self.headId);
    mypixmap=QPixmap(path);
    mypixmap=mypixmap.scaled(QSize(60,60),Qt::IgnoreAspectRatio);
    mypixmap=Globalobserver::PixmapToRound(mypixmap,mypixmap.width()/2);
    //默认失活
    ui->pushButton_send->setEnabled(false);
    ui->pushButton_send->setStyleSheet("#pushButton_send\n{\nbackground-color: rgb(99, 188, 255);\nborder-radius: 5px;\n}");
}

ChatDialog::~ChatDialog()
{
    delete ui;
}

void ChatDialog::CreateWidgetL_R(int i, QString data)
{
    QFont font1;//设置字体
    font1.setFamily("Microsoft YaHei");//字体
    font1.setPointSize(10);//字号
    font1.setStyleStrategy(QFont::PreferAntialias);//中文反锯齿

    QWidget * widget = new QWidget();//创建控件
    widget->setStyleSheet("background:rgba(0,0,0,0);");//设置样式

    QHBoxLayout *horLayout = new QHBoxLayout();//水平布局
    horLayout->setContentsMargins(0,0,0,0);//与四周的边框距离
    horLayout->setSpacing(0);//布局内部控件的间距

    QPushButton * btnicon = new QPushButton();//创建按钮
    btnicon->setFixedSize(55,40);//设置固定大小
    btnicon->setIconSize(QSize(40,40));//设置图像大小
    btnicon->setStyleSheet("background:rgba(0,0,0,0);");//设置样式

    QLabel * label = new QLabel(data);//创建标签
    label->setFont(font1);//设置字体
    label->setStyleSheet("background-color: rgb(149,236,105);border-style:solid;border-width:2px;border-color: rgb(105, 105, 105);border-radius:10px;");//设置样式
    label->setTextInteractionFlags(Qt::TextSelectableByMouse);//设置鼠标可以选中该标签的文字

    label->adjustSize();//文本根据内容自适应
    label->setWordWrap(true);//允许自动换行
    label->resize(label->width()+20, label->height()*1.5f);//把文本的高度调大些，因为控件加入QListyWidget中后文本会被缩短

    //设置整体布局的大小
    widget->setFixedSize(700,label->height()+10);

    if(i==1)//收到的消息
    {
        label->setAlignment(Qt::AlignVCenter|Qt::AlignLeft);//设置局中样式
        horLayout->addWidget(btnicon);//添加控件
        horLayout->addWidget(label);//添加控件
        horLayout->addStretch();//平均分配Layout 添加拉伸空间 增加伸缩量
        btnicon->setIcon(this->pixmap);//设置图像
    }
    else
    {
        label->setAlignment(Qt::AlignVCenter|Qt::AlignRight);//设置局中样式
        horLayout->addStretch();//平均分配Layout 添加拉伸空间 增加伸缩量
        horLayout->addWidget(label);//添加控件
        horLayout->addWidget(btnicon);//添加控件
        btnicon->setIcon(this->mypixmap);//设置图像
    }
    widget->setLayout(horLayout);//设置布局
    //创建行对象
    QListWidgetItem * Listitem = new QListWidgetItem(ui->listWidget);
    //设置行对象尺寸
    Listitem->setSizeHint(QSize(widget->width(),widget->height()+10));  //每次改变Item的高度
    //三者进行绑定
    ui->listWidget->setItemWidget(Listitem,widget);
}

void ChatDialog::showWaitMsg(QStringList waitMsg)
{
    QStringList::iterator it;
    for(it=waitMsg.begin();it!=waitMsg.end();it++)
    {
        //把未读信息显示在左侧
//        qDebug()<<(*it);
        if((*it).contains("/"))
        {
            (*it).chop(1);
            qDebug()<<(*it);
            CreateExpressionL_R(1,(*it));

        }
        else
        {
//            qDebug()<<"msgwait";
            CreateWidgetL_R(1,(*it));
        }
    }
}

void ChatDialog::on_pushButton_send_clicked()
{
    //获取发送的文本内容
    QString msg = ui->textEdit->toPlainText();
    //构建json串
    QString json = MsgBuilder::buildSendMsg(self,fri_user,msg);
    socket->write(json.toLocal8Bit());
    //把发送的消息显示在右侧,清空发送区
    CreateWidgetL_R(0,msg);
    ui->textEdit->clear();
}

void ChatDialog::on_pushButton_close_clicked()
{
    this->hide();
}

void ChatDialog::on_textEdit_textChanged()
{
    QString msg=ui->textEdit->toPlainText();
    if(msg.isEmpty())
    {
        ui->pushButton_send->setEnabled(false);
        ui->pushButton_send->setStyleSheet("#pushButton_send\n{\nbackground-color: rgb(99, 188, 255);\nborder-radius: 5px;\n}");
    }
    else
    {
        ui->pushButton_send->setEnabled(true);
        ui->pushButton_send->setStyleSheet("#pushButton_send\n{\nbackground-color: rgb(99, 188, 255);\nborder-radius: 5px;\n}");
    }
}

void ChatDialog::on_toolButton_5_clicked()
{
    expression *ep=new expression(this);   
    connect(ep,SIGNAL(sendIndex(QString)),this,SLOT(slot_showexpression(QString)));
    ep->show();
}

void ChatDialog::slot_showexpression(QString index)
{
    CreateExpressionL_R(0,index);
    QString msg = MsgBuilder::buildSendFace(self,fri_user,index);
    socket->write(msg.toLocal8Bit());
}
void ChatDialog::CreateExpressionL_R(int i, QString data)
{
    QWidget * widget = new QWidget();//创建控件
    widget->setStyleSheet("background:rgba(0,0,0,0);");//设置样式

    QHBoxLayout *horLayout = new QHBoxLayout();//水平布局
    horLayout->setContentsMargins(0,0,0,0);//与四周的边框距离
    horLayout->setSpacing(0);//布局内部控件的间距
    //拼接路径
    QString path=QString(":/e/expression/e%1.png").arg(data);
    //创建图像
    QPixmap p(path);
    //创建按钮对象（动态创建）
    QPushButton * label = new QPushButton();//创建按钮
    label->setIcon(QIcon(p));
    label->setIconSize(QSize(50,50));//设置图像大小
//    btnicon->setStyleSheet("background:rgba(0,0,0,0);");//设置样式

    QPushButton * btnicon = new QPushButton();//创建按钮
    btnicon->setFixedSize(55,40);//设置固定大小
    btnicon->setIconSize(QSize(40,40));//设置图像大小
    btnicon->setStyleSheet("background:rgba(0,0,0,0);");//设置样式
    label->adjustSize();//文本根据内容自适应

    //设置整体布局的大小
    widget->setFixedSize(700,label->height()+10);

    if(i==1)//收到的消息
    {
//        label->setAlignment(Qt::AlignVCenter|Qt::AlignLeft);//设置局中样式
        horLayout->addWidget(btnicon);//添加控件
        horLayout->addWidget(label);//添加控件
        horLayout->addStretch();//平均分配Layout 添加拉伸空间 增加伸缩量
        btnicon->setIcon(this->pixmap);//设置图像
    }
    else
    {
//        label->setAlignment(Qt::AlignVCenter|Qt::AlignRight);//设置局中样式
        horLayout->addStretch();//平均分配Layout 添加拉伸空间 增加伸缩量
        horLayout->addWidget(label);//添加控件
        horLayout->addWidget(btnicon);//添加控件
        btnicon->setIcon(this->mypixmap);//设置图像
    }
    widget->setLayout(horLayout);//设置布局
    //创建行对象
    QListWidgetItem * Listitem = new QListWidgetItem(ui->listWidget);
    //设置行对象尺寸
    Listitem->setSizeHint(QSize(widget->width(),widget->height()+10));  //每次改变Item的高度
    //三者进行绑定
    ui->listWidget->setItemWidget(Listitem,widget);
}
