#ifndef GLOBALOBSERVER_H
#define GLOBALOBSERVER_H
#include <QPixmap>
#include <QPainter>
#include <QBitmap>

//该类用于设置圆形头像
class Globalobserver
{

public:
    //函数声明
    static QPixmap PixmapToRound(const QPixmap &src, const int &radius);   //图片反锯齿化
    //参数1：图像类对象，参数2：圆形半径
    Globalobserver();
    ~Globalobserver();
};

#endif // GLOBALOBSERVER_H
