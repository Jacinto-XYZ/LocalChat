#include "friendform.h"
#include "ui_friendform.h"


FriendForm::FriendForm(UserData user, QWidget *parent) :
    QWidget(parent),user(user),
    ui(new Ui::FriendForm)
{
    ui->setupUi(this);
    //显示好友头像
    QString path=QString(":/head/head%1.jpg").arg(user.headId);
    QPixmap p(path);
    p=p.scaled(QSize(80,80),Qt::IgnoreAspectRatio);
    p=Globalobserver::PixmapToRound(p,p.width()/2);
    ui->label_img->setPixmap(p);
    //显示名字
    QString name=QString("%1(%2)").arg(user.nickName).arg(user.userId);
    ui->label_name->setText(name);
}

FriendForm::~FriendForm()
{
    delete ui;
}

void FriendForm::msgTips(bool flag)
{
    //判断flag, 如果为真，显示条数，如果为假，清空条数
    if(flag)
    {
        //flag: true --> 未读信息数
        QPixmap pix(20,20);//图片
        pix.fill(Qt::transparent);//透明
        QPainter painter(&pix);//创建
        painter.setPen(Qt::transparent);//设置画笔颜色
        painter.setBrush(Qt::red);//设置笔刷
        painter.drawEllipse(pix.rect());//画椭圆
        QTextOption textop;//设置文本
        textop.setAlignment(Qt::AlignCenter);//设置局中效果
        painter.setPen(Qt::white);//设置画笔颜色
        //显示未读信息数
        painter.drawText(pix.rect(),QString::number(waitMsg.size()),textop);
        ui->label_num->setPixmap(pix);//显示在ui上
    }
    else
    {
        ui->label_num->clear();
    }
}
