#ifndef FRIENDFORM_H
#define FRIENDFORM_H

#include "MsgBuilder.h"
#include <QWidget>
#include "globalobserver.h"

namespace Ui {
class FriendForm;
}

class FriendForm : public QWidget
{
    Q_OBJECT

public:
    explicit FriendForm(UserData user, QWidget *parent = 0);
    ~FriendForm();
    inline UserData getUser()//获取好友消息
    {
        return user;
    }
    //追加未读信息
    inline void addWaitMsg(QString msg)
    {
        //追加
        waitMsg.append(msg);
    }
    //获取未读信息
    inline QStringList getWaitMsg()
    {
        QStringList tmp=waitMsg;
        waitMsg.clear();
        return tmp;
    }
    //显示未读信息的数量
    void msgTips(bool flag);

private:
    Ui::FriendForm *ui;
    UserData user;
    //保存未读信息的容器
    QStringList waitMsg;
};

#endif // FRIENDFORM_H
