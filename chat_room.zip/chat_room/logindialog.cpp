#include "logindialog.h"
#include "ui_logindialog.h"

LoginDialog::LoginDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoginDialog)
{
    ui->setupUi(this);
    QMovie *movie=new QMovie(this);
    //设置动图
    movie->setFileName(":/lib/background.gif");
    //设置大小，缩放
    movie->setScaledSize(ui->label_back->size());
    //显示动图
    ui->label_back->setMovie(movie);
    //播放
    movie->start();
    //设置窗体最大化和最小化
    Qt::WindowFlags windowFlag = Qt::Dialog;
    windowFlag |= Qt::WindowMinimizeButtonHint;
    windowFlag |= Qt::WindowMaximizeButtonHint;
    windowFlag |= Qt::WindowCloseButtonHint;
    setWindowFlags(windowFlag);
    //设置窗体（左上）图标和文字
    setWindowIcon(QIcon(":/lib/OIP-C.jpg"));
    setWindowTitle("chatroom");
    socket=MySocket::getpoint();
    connect(socket,SIGNAL(connected()),this,SLOT(slot_connected()));
    connect(socket,SIGNAL(disconnected()),this,SLOT(slot_disconnected()));
    initAction();
    connect(socket,SIGNAL(readyRead()),this,SLOT(slot_read()));
}

void LoginDialog::dealUserLogin(QByteArray data)
{
    //解析json
    vector<UserData> friends;
    UserData hostData;
    friends=MsgBuilder::parseLoginSucReturnMsg(hostData,data);
    //关闭主页面
    this->close();   
    //页面切换好友列表
    Friendlist *fl=new Friendlist(hostData,friends,this);//堆空间延长生命周期
//    connect(this,SIGNAL(sendMsg(QByteArray)),fl,SLOT(slot_getMsg(QByteArray)));
    fl->show();
}
//关闭套接字连接
void LoginDialog::closeEvent(QCloseEvent *)
{
    disconnect(socket,SIGNAL(readyRead()),this,SLOT(slot_read()));
}

LoginDialog::~LoginDialog()
{
    delete ui;
}

void LoginDialog::on_pushButton_register_clicked()
{
    registerDialog* reg=new registerDialog(this);
    //断开连接
    disconnect(socket,SIGNAL(readyRead()),this,SLOT(slot_read()));
    //阻塞显示
    reg->exec();
    //重新连接
    connect(socket,SIGNAL(readyRead()),this,SLOT(slot_read()));
}

void LoginDialog::on_pushButton_connect_clicked()
{
    //获取输入的ip地址
    QString ip=ui->lineEdit_ip->text();
    //连接主机
    socket->connectToHost(QHostAddress(ip),12345);
}

void LoginDialog::slot_connected()
{
    qDebug()<<"连接成功";
    ui->lineEdit_id->setEnabled(true);
    ui->lineEdit_password->setEnabled(true);
    ui->pushButton_login->setEnabled(true);
    ui->pushButton_register->setEnabled(true);
}

void LoginDialog::slot_disconnected()
{
    qDebug()<<"断开连接成功";
    ui->lineEdit_id->setEnabled(false);
    ui->lineEdit_password->setEnabled(false);
    ui->pushButton_login->setEnabled(false);
    ui->pushButton_register->setEnabled(false);
}
void LoginDialog::initAction()
{
    //创建一个action
    QAction *searchAction = new QAction(ui->lineEdit_id);
    //填加图标
    searchAction->setIcon(QIcon(":/lib/suo.png"));
    //表示action所在方位（左侧）。
    ui->lineEdit_id->addAction(searchAction,QLineEdit::LeadingPosition);

    QAction *searchAction_2 = new QAction(ui->lineEdit_password);
    searchAction_2->setIcon(QIcon(":/lib/jianpan.png"));
    //表示action所在方位（右侧）。
    ui->lineEdit_password->addAction(searchAction_2,QLineEdit::TrailingPosition);

    QAction *searchAction_3 = new QAction(ui->lineEdit_ip);
    searchAction_3->setIcon(QIcon(":/lib/fdog.png"));
    //表示action所在方位（左侧）。
    ui->lineEdit_ip->addAction(searchAction_3,QLineEdit::LeadingPosition);
}

void LoginDialog::on_pushButton_login_clicked()
{
    QString id=ui->lineEdit_id->text();
    QString password=ui->lineEdit_password->text();
    //判断内容是否为空
    if(id.isEmpty()||password.isEmpty())
    {
        QMessageBox::warning(this,"登录警告！","账号或密码缺失");
        return;
    }
    UserData user;
    user.userId=id.toInt();
    user.passWord=password;
    QString jsonstr = MsgBuilder::buildLoginMsg(user);

    socket->write(jsonstr.toLocal8Bit());
}

void LoginDialog::slot_read()
{

    QByteArray array;
    array=socket->readAll();
    int type=MsgBuilder::msgType(array);
    switch (type)
    {
    case MsgBuilder::loginSucReturn:
        dealUserLogin(array);
        break;
    case MsgBuilder::loginLoseReturn:
        QMessageBox::information(this,"登录提示","Login fail");
        break;
    default:
        break;
    }

}
