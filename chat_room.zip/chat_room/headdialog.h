#ifndef HEADDIALOG_H
#define HEADDIALOG_H
#include <QPushButton>
#include <QDialog>

namespace Ui {
class HeadDialog;
}

class HeadDialog : public QDialog
{
    Q_OBJECT

public:
    explicit HeadDialog(QWidget *parent = 0);
    ~HeadDialog();
    void autoInitial();
private slots:
    void slot_btn_clicked();//按钮点击槽函数
signals://自定义信号函数
    void sendIndex(QString index);
private:
    Ui::HeadDialog *ui;
};

#endif // HEADDIALOG_H
