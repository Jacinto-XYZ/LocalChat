#ifndef LOGINDIALOG_H
#define LOGINDIALOG_H
#include "registerdialog.h"
#include <QDialog>
#include <QMovie>
#include "mysocket.h"
#include <QAction>
#include <QMessageBox>//消息提示框
#include "friendlist.h"

namespace Ui {
class LoginDialog;
}

class LoginDialog : public QDialog
{
    Q_OBJECT

public:
    explicit LoginDialog(QWidget *parent = 0);
    void dealUserLogin(QByteArray data);//deal login
    void closeEvent(QCloseEvent*);
    void initAction();
    ~LoginDialog();

private slots:
    void on_pushButton_register_clicked();

    void on_pushButton_connect_clicked();
    void slot_connected();
    void slot_disconnected();
    void on_pushButton_login_clicked();
    void slot_read();
//signals:
//    void sendMsg(QByteArray data);
private:
    Ui::LoginDialog *ui;
    MySocket *socket;
};

#endif // LOGINDIALOG_H
