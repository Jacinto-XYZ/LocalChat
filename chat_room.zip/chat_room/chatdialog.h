#ifndef CHATDIALOG_H
#define CHATDIALOG_H

#include <QDialog>
#include "mysocket.h"
#include "globalobserver.h"
#include <QLabel>
#include "expression.h"
#include <cstdio>
#include <cstring>

namespace Ui {
class ChatDialog;
}

class ChatDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ChatDialog(UserData fri_user,QWidget *parent = 0);
    ~ChatDialog();
    //发送信息在右侧 收到信息在左侧
    void CreateWidgetL_R(int i,QString data);
    //显示未读信息
    void showWaitMsg(QStringList waitMsg);
    void CreateExpressionL_R(int i, QString data);
private slots:
    void on_pushButton_send_clicked();

    void on_pushButton_close_clicked();

    void on_textEdit_textChanged();

    void on_toolButton_5_clicked();

    void slot_showexpression(QString index);

private:
    Ui::ChatDialog *ui;
    //创建套接字指针
    MySocket *socket;
    //保存个人信息
    UserData self;
    //保存好友信息
    UserData fri_user;
    //保存自己的头像
    QPixmap mypixmap;
    //保存好友的头像
    QPixmap pixmap;
};

#endif // CHATDIALOG_H
