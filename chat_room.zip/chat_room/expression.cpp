#include "expression.h"
#include "ui_expression.h"

expression::expression(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::expression)
{
    ui->setupUi(this);
    this->autoInitial();
}

expression::~expression()
{
    delete ui;
}
void expression::autoInitial()
{
    //创建行
    int rows=0;
    //创建列
    int cols=0;
    //按钮添加到网格中
    for(int i=1;i<20;i++)
    {
        //拼接路径
        QString path=QString(":/e/expression/e%1.png").arg(i);
//        QString path=QString(":/head/head%1.jpg").arg(i);
        //创建图像
        QPixmap p(path);
        //创建按钮对象（动态创建）
//        QPushButton *btn=new QPushButton(this);
        QPushButton *btn=new QPushButton(this);
        //显示图片
        btn->setIcon(QIcon(p));
        //设置图像大小
        btn->setIconSize(QSize(120,120));
        //设置objectName
        btn->setObjectName(QString::number(i));
        //连接函数
        connect(btn,SIGNAL(clicked()),this,SLOT(slot_btn_clicked()));
        //添加控件
        ui->gridLayout->addWidget(btn,rows,cols,1,1);
        //行
        rows = i%5==0 ? rows+1 : rows;
        //列
        cols = i%5==0 ? 0 : cols+1;
    }
}

void expression::slot_btn_clicked()
{
    //获取当前发送信号对象
    QObject *obj=QObject::sender();
    //获object_name
    QString name=obj->objectName();
    //发送信号
    emit sendIndex(name);
    //隐藏画面
    this->hide();
}
