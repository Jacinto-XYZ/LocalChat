#ifndef MSGBULIDER_H
#define MSGBULIDER_H

#include <QString>
#include <QJsonObject>
#include <QJsonDocument>
#include <vector>
using namespace std;
#include <QJsonArray>

//结构体：描述人的信息
struct UserData
{
    int userId;//账号
    QString nickName;//昵称
    QString passWord;//密码
    int headId;//头像id
    //map插入元素，比较大小
    bool operator<(const UserData& other)const
    {
        return this->userId < other.userId;
    }
};
//json的构建和解析
class MsgBuilder
{
public:
    //消息类型
    enum MsgType
    {
        registerUser,       //注册用户(客户端->服务器)
        registerUserReturn, //注册用户服务器返回(服务器->客户端)
        login,              //登录(客户端->服务器)
        loginSucReturn,     //登录成功服务器返回(服务器->客户端)
        loginLoseReturn,    //登录失败服务器返回(服务器->客户端)
        sendMsg,            //发送聊天消息(客户端->服务器)
        receiveMsg,         //收到聊天信息(服务器->客户端)
        sendFace,            //发送聊天表情(客户端->服务器)
        receiveFace,         //收到聊天表情(服务器->客户端)
        userOnline,         //用户上线(服务器->客户端)
        userOffline         //用户下线(服务器->客户端)
    };

public:
    //获取消息类型
    static int msgType(QByteArray& arr);
    //以build开头的函数都是在构建json串 以parse开头的函数都是在解析json串
    //注册用户
    static QString buildRegisterUserMsg(UserData& user);
    static UserData parseRegisterUserMsg(QByteArray& arr);
    //注册用户返回
    static QString buildRegisterUserReturnMsg(int id);
    static int parseRegisterUserReturnMsg(QByteArray& arr);
    //登录
    static QString buildLoginMsg(UserData &user);
    static UserData parseLoginMsg(QByteArray& arr);
    //登录返回
    static QString buildLoginReturnMsg(bool flag, UserData user = UserData(),vector<UserData> friends=vector<UserData>());
    static vector<UserData> parseLoginSucReturnMsg(UserData& hostData, QByteArray& arr);
    //发送聊天数据
    static QString buildSendMsg(UserData from, UserData to, QString msg);
    static QString parseSendMsg(QByteArray &arr, UserData& from, UserData& to);
    //收到聊天信息
    static QString buildReceiveMsg(UserData from, QString msg);
    static QString parseReceiveMsg(QByteArray &arr, UserData& from);
    //用户上线
    static QString buildUserOnline(UserData& user);
    static UserData parseUserOnline(QByteArray &arr);
    //用户下线
    static QString buildUserOffline(UserData user);
    static UserData parseUserOffline(QByteArray &arr);  
    //发送表情数据
    static QString buildSendFace(UserData from, UserData to, QString msg);
    static QString parseSendFace(QByteArray &arr, UserData& from, UserData& to);
    //收到表情信息
    static QString buildReceiveFace(UserData from, QString msg);
    static QString parseReceiveFace(QByteArray &arr, UserData& from);
};

#endif // MSGBULIDER_H
