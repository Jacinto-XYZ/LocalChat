#ifndef MYSOCKET_H
#define MYSOCKET_H
#include <QTcpSocket>
#include <QHostAddress>
#include "MsgBuilder.h"
#include <QTcpSocket>

class MySocket:public QTcpSocket
{
//单例模式：一个类只有一个实例化对象
    //1.私有构造和拷贝构造，不能类外创建对象
    //私有静态指针
private:
    static MySocket *one;
    MySocket();
    MySocket(const MySocket& other);
    UserData self;
public:
    ~MySocket();
    static MySocket* getpoint();
    //设置信息
    inline void setSelf(UserData user)
    {
        self=user;
    }
    //获取信息
    inline UserData getSelf()
    {
        return self;
    }
};

#endif // MYSOCKET_H
