#include "registerdialog.h"
#include "ui_registerdialog.h"

registerDialog::registerDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::registerDialog)
{
    ui->setupUi(this);
    //设置窗体（左上）图标和文字
    setWindowIcon(QIcon(":/lib/OIP-C.jpg"));
    setWindowTitle("register");
    socket=MySocket::getpoint();
    connect(socket,SIGNAL(readyRead()),this,SLOT(slot_readRead()));

}

registerDialog::~registerDialog()
{
    delete ui;
}

void registerDialog::closeEvent(QCloseEvent *)
{
    disconnect(socket,SIGNAL(readyRead()),this,SLOT(slot_readRead()));
}

void registerDialog::on_pushButton_choose_clicked()
{
    HeadDialog* head=new HeadDialog(this);
    //建立对象，由对象发送的信号，所以connect要写在这
    connect(head,SIGNAL(sendIndex(QString)),this,SLOT(slot_getIndex(QString)));
    head->show();

}

void registerDialog::slot_getIndex(QString index)
{
    //字符串转数字
    headId=index.toInt();
    //拼接
    QString path=QString(":head/head%1.jpg").arg(headId);
    //以上两行仅仅为了复习知识点
    //设置图像
    ui->label_head->setPixmap(QPixmap(path));
}


void registerDialog::on_pushButton_register_clicked()
{
   UserData msg;
   msg.nickName=ui->lineEdit_nickname->text();
   msg.passWord=ui->lineEdit_password->text();
   msg.headId=headId;
   QString jsonstr= MsgBuilder::buildRegisterUserMsg(msg);
   socket->write(jsonstr.toLocal8Bit());
}

void registerDialog::slot_readRead()
{
    //获取接受信息
    QByteArray data = socket->readAll();
    //解析
    int id = MsgBuilder::parseRegisterUserReturnMsg(data);
    //显示id
    ui->label_id->setNum(id);
}
