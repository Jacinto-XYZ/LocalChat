#ifndef FRIENDLIST_H
#define FRIENDLIST_H
#include <QMainWindow>
#include "globalobserver.h"
#include "MsgBuilder.h"
#include "friendform.h"
#include "mysocket.h"
#include <QListWidgetItem>
#include "chatdialog.h"

namespace Ui {
class Friendlist;
}

//封装好友聊天信息
struct ItemAndChat
{
    ChatDialog* chat;//单聊
    FriendForm *f;//自定义控件,用以显示未读消息
    bool isShow;//标志位，用以确认窗口是否隐藏
};

class Friendlist : public QMainWindow
{
    Q_OBJECT

public:
    explicit Friendlist(UserData user,vector<UserData> friends,QWidget *parent = 0);
    ~Friendlist();
//private slots:
//    void slot_getMsg(QByteArray data);
    void initList();//显示好友列表
    void dealUserOnline(QByteArray data);
    void dealUserOffline(QByteArray data);
    void dealUserRecvMsg(QByteArray data);//处理用户接受信息
    void dealUserRecvFace(QByteArray data);//处理用户接受表情
private slots:
    void slot_onReadyRead();//接受信息槽函数
    //双击行对象的槽函数
    void on_listWidget_itemDoubleClicked(QListWidgetItem *item);

private:
    Ui::Friendlist *ui;
    vector<UserData> friends;
    //创建套接字指针
    MySocket* socket;
    //聊天好友管理容器
    map<UserData,ItemAndChat> chatFriends;
};

#endif // FRIENDLIST_H
