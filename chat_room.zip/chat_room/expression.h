#ifndef EXPRESSION_H
#define EXPRESSION_H

#include <QDialog>
#include <QPushButton>
#include <QDialog>

namespace Ui {
class expression;
}

class expression : public QDialog
{
    Q_OBJECT

public:
    explicit expression(QWidget *parent = 0);
    ~expression();
    void autoInitial();

private slots:
    void slot_btn_clicked();//按钮点击槽函数

signals://自定义信号函数
    void sendIndex(QString index);

private:
    Ui::expression *ui;
};

#endif // EXPRESSION_H
