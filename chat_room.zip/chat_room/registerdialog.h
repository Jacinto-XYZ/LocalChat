#ifndef REGISTERDIALOG_H
#define REGISTERDIALOG_H
#include "headdialog.h"
#include <QDialog>
#include "mysocket.h"
#include "MsgBuilder.h"
#include <QCloseEvent>

namespace Ui {
class registerDialog;
}

class registerDialog : public QDialog
{
    Q_OBJECT

public:
    explicit registerDialog(QWidget *parent = 0);
    ~registerDialog();
    //重写关闭事件,按×关闭对话框就会触发该时间
    void closeEvent(QCloseEvent *);

private slots:
    void on_pushButton_choose_clicked();
    void slot_getIndex(QString index);//接受head的信号

    void on_pushButton_register_clicked();
    void slot_readRead();//接受信息

private:
    Ui::registerDialog *ui;
    MySocket *socket;
    int headId;
};

#endif // REGISTERDIALOG_H
