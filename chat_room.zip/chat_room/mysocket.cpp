#include "mysocket.h"

MySocket* MySocket::one=nullptr;//需要在全局处声明

MySocket::MySocket()
{

}

MySocket::~MySocket()
{
    delete one;
}

MySocket *MySocket::getpoint()
{
    if(one==nullptr)
    {
        one=new MySocket;
    }
    return one;
}

