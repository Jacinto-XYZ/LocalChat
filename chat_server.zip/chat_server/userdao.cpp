#include "userdao.h"

UserDao* UserDao::ins=new UserDao;

UserDao::UserDao()
{
    //加载数据库驱动
    db=QSqlDatabase::addDatabase("QSQLITE");
    //设置数据库主机名称
    db.setHostName("testdb");
    //设置数据库文件名字
    db.setDatabaseName("test.db");
    //打开数据库
    db.open();
    //创建用户表
    createTable();
}

UserDao *UserDao::getins()
{
    return ins;
}

void UserDao::createTable()
{
    //创建操作数据库的类对象
    QSqlQuery query;
    //编写sql语句
    QString sql="create table if not exists user_info"
                "(userid integer primary key autoincrement,"
                "nickname varchar(20),"
                "password varchar(20),"
                "headid integer);";
    //执行sql语句
    bool ok=query.exec(sql);
    if(ok)
    {
        qDebug()<<"create table success";
        sql="insert into user_info values(10000,'admin','1','1');";
        if(query.exec(sql))
            qDebug()<<"insert admin success";
        else
            qDebug()<<"insert admin fail";
    }
    else
    {
        qDebug()<<"create table fail";
    }
}

void UserDao::insertvalues(UserData& data)
{
//    QString sql=QString("insert into user_info(nickname,password,headid) values('%1','%2',%3);").arg(data.nickName).arg(data.passWord).arg(data.headId);
    QString sql=QString("insert into user_info(nickname,password,headid) values(?,?,?);");//?占位符可以用query类函数替换
    QSqlQuery query;
    query.prepare(sql);
    //绑定数据
    query.bindValue(0,data.nickName);
    query.bindValue(1,data.passWord);
    query.bindValue(2,data.headId);
    if(query.exec())//用以上方法，prepare过，此处不写sql
    {
        qDebug()<<"add data success";
//        sql="select userid from user_info where "
    }
    else
        qDebug()<<"add data fail";

}

int UserDao::getUserId()
{
    //sql文 last_insert_rowid();获取最新插入的id
    QString sql="select last_insert_rowid();";
    QSqlQuery query;
    query.exec(sql);
    if(query.next())//如果next有值，查询成功,此处仅一条
    {
//        id=query.value(0).toInt();//0表示第一列
        int id=query.record().value(0).toInt();
        //一条记录的第一列，转int
        return id;
    }
    else
        return -1;
}

bool UserDao::usercheck(UserData &data)
{
    QString sql=QString("select * from user_info where userid=%1 and password='%2'").arg(data.userId).arg(data.passWord);
    QSqlQuery query;
    bool ok;
    ok=query.exec(sql);
    if(ok)
    {
        qDebug()<<"search success";
        if(query.next())
        {
            //成功了要同步添加headid数据
            data.headId=query.record().value("headid").toInt();
            data.nickName=query.record().value("nickname").toString();
            qDebug()<<"exist";
            return true;
        }
    }
    else
        qDebug()<<"search fail";
    return false;
}

UserDao::~UserDao()
{
    delete ins;
    db.close();
}

