#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QHostInfo>
#include <QHostAddress>
#include "MsgBuilder.h"
#include "myserver.h"
#include "socketthread.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void initIp();//初始IP

//private slots:
//    void slot_newconnect();//客户端连接对应的槽函数
private:
    Ui::MainWindow *ui;
    MyServer* server;//创建服务器指针
//    QTcpSocket* socket;//创建套接字指针

};

#endif // MAINWINDOW_H
