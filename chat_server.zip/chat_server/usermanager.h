#ifndef USERMANAGER_H
#define USERMANAGER_H
#include <map>
#include "MsgBuilder.h"
#include "socketthread.h"
#include <QMutex>
#include <vector>

class UserManager
{
private:
    static UserManager* one;
    UserManager();
    UserManager(const UserManager& o);
    map<UserData,SocketThread*> onlineUsers;
    QMutex mutex;
public:   
    static UserManager* getOne();
    //插入数据
    void insertMap(UserData user,SocketThread* st);
    //获取在线好友
    vector<UserData> getOnlineFriends();
    //判断是否存在,不存在放map
    bool isExists(UserData user);
    //获取在线人员线程，用途：通知其他线程有新的线程
    vector<SocketThread*> getonlineThread();
    //删除
    void eraseMap(UserData user);
    //获取指定线程，用于私聊
    SocketThread* getRecvThread(UserData user);
    ~UserManager();
};

#endif // USERMANAGER_H
