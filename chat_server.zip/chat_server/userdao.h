#ifndef USERDAO_H
#define USERDAO_H
#include <QSqlDatabase>//数据库
#include <QSqlQuery>//操作
#include <QSqlRecord>//记录
#include <QDebug>
#include "MsgBuilder.h"

class UserDao//封装的内容一般用dao称呼
{
private:
    static UserDao* ins;
    UserDao();
    UserDao(const UserDao& other);
    QSqlDatabase db;
public:
    static UserDao* getins();
    void createTable();
    void insertvalues(UserData &data);
    //查询刚插入的id
    int getUserId();
    bool usercheck(UserData &data);
    ~UserDao();
};

#endif // USERDAO_H
