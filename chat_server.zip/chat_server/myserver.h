#ifndef MYSERVER_H
#define MYSERVER_H
#include <QTcpServer>
#include <QTcpSocket>
#include "socketthread.h"


class MyServer:public QTcpServer
{
public:
    MyServer(QObject *parent = 0);
    //重写incomingconnection函数 soketDescriptor:套接字描述符，或者sd标志
    //因为线程内无法使用socket，库类提供了以下函数作为接口以实现该需求
    //当有新的连接，会触发以下函数
    void incomingConnection(qintptr socketDescriptor);
    ~MyServer();
};

#endif // MYSERVER_H
